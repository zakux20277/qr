package com.qrcode.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
