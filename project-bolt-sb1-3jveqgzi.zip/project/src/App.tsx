import React, { useState } from 'react';
import QRCode from 'qrcode.react';
import { Link2, Download } from 'lucide-react';

function App() {
  const [url, setUrl] = useState('');

  const downloadQR = () => {
    const canvas = document.querySelector('canvas');
    if (canvas) {
      const pngUrl = canvas
        .toDataURL('image/png')
        .replace('image/png', 'image/octet-stream');
      const downloadLink = document.createElement('a');
      downloadLink.href = pngUrl;
      downloadLink.download = 'qr-code.png';
      document.body.appendChild(downloadLink);
      downloadLink.click();
      document.body.removeChild(downloadLink);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-blue-100 p-4 safe-area-top">
      <div className="max-w-md mx-auto bg-white rounded-xl shadow-lg p-6 space-y-6">
        <div className="text-center">
          <h1 className="text-3xl font-bold text-blue-600 mb-2">مولد رمز QR</h1>
          <p className="text-gray-600">أدخل الرابط لإنشاء رمز QR الخاص بك</p>
        </div>

        <div className="space-y-4">
          <div className="relative">
            <Link2 className="absolute right-3 top-3 text-gray-400" size={20} />
            <input
              type="url"
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              placeholder="أدخل الرابط هنا..."
              className="w-full pr-10 py-2 px-4 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none"
              dir="ltr"
            />
          </div>

          <div className="flex justify-center">
            {url && (
              <div className="p-4 bg-white rounded-lg shadow-sm">
                <QRCode value={url} size={200} level="H" />
              </div>
            )}
          </div>

          {url && (
            <button
              onClick={downloadQR}
              className="w-full flex items-center justify-center gap-2 bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors"
            >
              <Download size={20} />
              <span>تحميل رمز QR</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

export default App;